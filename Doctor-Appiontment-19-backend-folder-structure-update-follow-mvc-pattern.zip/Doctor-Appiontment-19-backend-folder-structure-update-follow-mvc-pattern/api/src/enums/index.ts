export enum BloodGroup {
    'O+', 'O-', 'B+', 'B-', 'AB+', 'AB-', 'A+', 'A-'
}

enum USER_RULES {
    "ADMIN",
    "PATIENT",
    "DOCTOR"
}